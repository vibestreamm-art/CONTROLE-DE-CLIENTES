---
name: Escopo e restrições do produto
description: Requisitos do usuário para o aplicativo e limites para o desenvolvimento.
---

O usuário quer um aplicativo profissional, simples e rápido para Android 10 ou superior, com estrutura para gerar um APK instalável. Deve incluir clientes, vendas, entradas e saídas, pagamentos, dívidas e cobranças, notificações de vencimento e painel financeiro.

Preservar o README existente e trabalhar no mesmo repositório. Utilizar ferramentas gratuitas sempre que possível; não contratar serviços nem gerar custos.

**Why:** requisitos e restrições explícitos do usuário.

**How to apply:** desenvolver o app Android nativo em Kotlin neste repositório, mantendo o README e priorizando ferramentas gratuitas. Gerar e testar um APK local quando possível, sem contratar serviços pagos.
